package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{
 
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Nicholas Markel";

    	String sha256hex = DigestUtils.sha256Hex(data);
     	
        return "Hello " + data + "!   Your SHA 256 checksum is: " + sha256hex;
    } 
}